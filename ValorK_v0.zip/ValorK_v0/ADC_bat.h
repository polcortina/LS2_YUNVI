

#ifndef ADC_BAT_H_
#define ADC_BAT_H_

#include "HEADER.h"

volatile float bateria_actual;

void ADC_configuracio(void);
void ADC_lectura(void);


#endif /* ADC_BAT_H_ */
