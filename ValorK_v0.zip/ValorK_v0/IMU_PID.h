/*
 * IMU_PID.h
 *
 *  Created on: 12 de des. 2019
 *      Author: ESG
 */


#ifndef IMU_PID_H_
#define IMU_PID_H_

#include "HEADER.h"


/* DEFINICION DE REGISTROS IMU */
#define AXH 0x3B
#define AXL 0x3C
#define AYH 0x3D
#define AYL 0x3E
#define AZH 0x3F
#define AZL 0x40
#define GXH 0x43
#define GXL 0x44
#define GYH 0x45
#define GYL 0x46
#define GZH 0x47
#define GZL 0x48

float tiempo_final, tiempo_inicial;

float pitch(void);
void delay(int i);
uint8_t I2C_ReadIMU(unsigned char dirReg);
void I2C_WriteIMU(unsigned char dirReg, unsigned char dato);
float processAcel(unsigned char H, unsigned char L);
float processGyro(unsigned char H, unsigned char L);
float calcul_PID(float tiempo_incial);
void Offset_IMU(void);

#endif /* IMU_PID_H_ */
