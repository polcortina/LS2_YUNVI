
#ifndef HEADER_H_
#define HEADER_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
//#include <xdc/runtime/Diags.h>
//#include <xdc/runtime/Log.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
//#include <ti/sysbios/hal/Hwi.h>
#include <ti/sysbios/hal/Timer.h>
#include <ti/sysbios/knl/Swi.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/ADC.h>
#include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
#include <ti/drivers/SPI.h>
#include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>
// #include <ti/drivers/WiFi.h>
#include <ti/drivers/PWM.h>


#include <math.h>

/* Board Header file */
#include "Board.h"
#include "nRF24.h"
#include "IMU_PID.h"
#include "PWM_MOTORS.h"
#include "ADC_bat.h"

/*driverlib headers*/
#include <ti/devices/msp432p4xx/driverlib/driverlib.h> /*necessary for timer*/

float res_pid;
uint8_t valor_anterior, valor_actual;


#endif /* HEADER_H_ */
