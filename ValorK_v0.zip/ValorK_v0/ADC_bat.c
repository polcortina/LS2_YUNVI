#include "HEADER.h"

ADC_Handle   adc;
ADC_Params   params;

void ADC_configuracio(void)
{


    ADC_Params_init(&params);

    adc = ADC_open(Board_ADC15, &params);

    if (adc == NULL)
    {
         System_printf("ADC0 convert failed\n");
         System_flush();
         while (1); /*dejamos el sistema colgado*/
     }



}

volatile float bateria_actual;

void ADC_lectura(void){

    uint16_t adcValue0; /* ADC conversion result variables */
    int_fast16_t bat;


    bat = ADC_convert(adc, &adcValue0);

    if (bat == ADC_STATUS_SUCCESS){
     bateria_actual = adcValue0 ;
    }
//    else{
//     System_printf("Error en la conversi�n");
//     System_flush();
//     ADC_close(adc);
//     while(1);
//    }

    //return bateria_actual;

}


