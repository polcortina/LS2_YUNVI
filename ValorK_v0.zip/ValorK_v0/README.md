### SysConfig Notice

All examples will soon be supported by SysConfig, a tool that will help you graphically configure your software components. A preview is available today in the examples/syscfg_preview directory. Starting in 3Q 2019, with SDK version 3.30, only SysConfig-enabled versions of examples will be provided. For more information, click [here](http://www.ti.com/sysconfignotice).

---
# uartlogging

---

## Example Summary

Application that uses the UART driver and LoggerIdle to send Log data to the
UART.

## Peripherals Exercised

* `Board_GPIO_LED0` - Indicates that the board was initialized within `main()`
* `Board_UART0` - Used to send data to the RTOS Analyzer

## Resources & Jumper Settings

> If you're using an IDE (such as CCS or IAR), please refer to Board.html in
your project directory for resources used and board-specific jumper settings.
Otherwise, you can find Board.html in the directory
&lt;SDK_INSTALL_DIR&gt;/source/ti/boards/&lt;BOARD&gt;.


## Example Usage

* Run the example. `Board_GPIO_LED0` turns ON to indicate driver
initialization is complete.

* This example also demonstrates RTOS Analyzer in CCS. This is accomplished
by sending log records via UART from the target to the host.  First make
sure to close any terminal windows that are connected to the board's
application UART COM port.  Load and run the example in CCS.
In the CCS Tools menu, select RTOS Analyzer -> Execution
Analysis.  When the Analysis Configuration window pops up, configure the
COM port to the board's application UART port.  The name of the COM port
should show up in the Port Name drop-down list under Transport Settings.
The baud rate should be left as 115200. Then click the "Start" button on
the Analysis Configuration window.  The Execution Graph will pop up and
display thread execution.

* The UART uses the default 115200 baud rate.

## Application Design Details

* This example demonstrates how to use an application to send Log data through a
UART. Log data will go through `Board_UART0` which is connected to your PC
through the same USB as the JTAG.

* Log events will be sent during idle through `Board_UART0` and can be analyzed
by RTOS Analyzer, or the data can be captured by a program running on the
host. Your host program for collecting the Log data will need to use the serial
COM port that is connected to `Board_UART0`.

* Power management is disabled in this example to allow the Idle loop
to run sufficiently often so that the LoggerIdle circular buffer does not fill
up, causing records to be lost.

TI-RTOS:

* When building in Code Composer Studio, the kernel configuration project will
be imported along with the example. The kernel configuration project is
referenced by the example, so it will be built first. The "release" kernel
configuration is the default project used. It has many debug features disabled.
These feature include assert checking, logging and runtime stack checks. For a
detailed difference between the "release" and "debug" kernel configurations and
how to switch between them, please refer to the SimpleLink MCU SDK User's
Guide. The "release" and "debug" kernel configuration projects can be found
under &lt;SDK_INSTALL_DIR&gt;/kernel/tirtos/builds/&lt;BOARD&gt;/(release|debug)/(ccs|gcc).
