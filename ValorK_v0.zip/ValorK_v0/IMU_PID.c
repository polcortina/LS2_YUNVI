#include "HEADER.h"

void delay(int i){
    int a = 0;
    while(a<i){
        a++;
    }
}

/* FUNCION LECTURA REGISTRO 8 BITS */
uint8_t I2C_ReadIMU(unsigned char dirReg){


    uint8_t rxBuffer[1];
    uint8_t txBuffer[] = {dirReg};


    I2C_Handle      i2c;
    I2C_Params      i2cParams;
    I2C_Transaction i2cTransaction;

    I2C_init();

    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c= I2C_open(1, &i2cParams);  //Este 1 es para usar la EUSCI1 (PINS: P6.4->SDA; P6.5->SCL)

    i2cTransaction.slaveAddress = 0x68;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 1;



    I2C_transfer(i2c, &i2cTransaction);

    delay(100);

    I2C_close(i2c);

    return rxBuffer[0];


}


/* FUNCION ESCRIBIR IMU */
void I2C_WriteIMU(unsigned char dirReg, unsigned char dato){
    uint8_t txBuffer[] = {dirReg, dato};
    uint8_t rxBuffer[0];

    I2C_Handle      i2c;
    I2C_Params      i2cParams;
    I2C_Transaction i2cTransaction;

    I2C_init();

    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    i2c= I2C_open(1, &i2cParams);

    i2cTransaction.slaveAddress = 0x68;
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 2;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    I2C_transfer(i2c, &i2cTransaction);

    delay(100);

    I2C_close(i2c);

}



/* FUNCIONES DE PROCESADO DE DATOS */
float processAcel(unsigned char H, unsigned char L){
    int16_t data16 = I2C_ReadIMU(H)<<8 | I2C_ReadIMU(L);
    float axisA = data16/2048.0;//16384.0;-->SI PONGO FONDO DE ESCALA DE +-2g (65536/4)
    return axisA;
}

float processGyro(unsigned char H, unsigned char L){
    int16_t data16 = I2C_ReadIMU(H)<<8 | I2C_ReadIMU(L);
    float axisG = data16/131.072;
    return axisG;
}


/* OBTENCION ANGULO DE ROTACION (PITCH) */
float AX;
float AY;
float AZ;

float pitch(void){
    ///***ACELERACIONES***///
    AX = processAcel(AXH, AXL);
    AY = processAcel(AYH, AYL);
    AZ = processAcel(AZH, AZL);
    float raiz = sqrt(AY*AY+AZ*AZ);
    float final = atanf(AX/raiz)*(180/M_PI);

    ///***VEL ANGULAR***///
    /*float GX = processGyro(GXH, GXL);
    float GY = processGyro(GYH, GYL);
    float GZ = processGyro(GZH, GZL);
    float raiz = sqrt(GY*GY+GZ*GZ);
    float final = atanf(GX/raiz)*(180/M_PI);*/

    return final;

}

void Offset_IMU(void){
    /*Variables Calculo Offset *************************************************************** */

    int16_t fabrica_off[3];
    float offset[3];
    int16_t dos_byte[3];
    int16_t desplazo_bytes[3];
    int16_t OFF_TOTAL[3];
    uint8_t off_final[6];
    float bufx, bufy, bufz;



    /*Variables media corrida de aceleraciones *********************************************** */
    int i = 0;
    //int length_bufs = 100; //sizeof(bufz) / sizeof(bufz[0]);
    //float bufx, bufy, bufz;

    int x = 1, y = 1, z = 0;

    while((x != 0) && (y != 0) && (z != 1)){

    /* Fondo de escala de +/- 16g (necesita este fondo para el offset) */
        I2C_WriteIMU(0x1C, 0x18);

        /* Meto los valores que trae la IMU por defecto en los registros de offset, es para no tener que estar sacando
         * y metiendo la IMU cada vez que hacemos una prueba
         */
        I2C_WriteIMU(0x77, 0xE5);
        I2C_WriteIMU(0x78, 0x46);
        I2C_WriteIMU(0x7A, 0xEB);
        I2C_WriteIMU(0x7B, 0x7A);
        I2C_WriteIMU(0x7D, 0x1F);
        I2C_WriteIMU(0x7E, 0x06);

        /* Convertimos cada offset de cada eje contenido en 2 registros diferentes (H y L) en un dato de 16 bits */
        fabrica_off[0] = 0xE5 << 8 | 0x46; //X
        fabrica_off[1] = 0xEB << 8 | 0x7A; //Y
        fabrica_off[2] = 0x1F << 8 | 0x06; //Z

        /* Hacemos una serie de lecturas de aceleracion con la IMU plana, luego calculamos una media de dichas lecturas
         * para posteriormente corregir el offset sabiendo que en plano, idealmente debemos leer: Ax = 0g; Ay = 0g; Az = 1g
         */

        bufx = processAcel(AXH, AXL);
        bufy = processAcel(AYH, AYL);
        bufz = processAcel(AZH, AZL);

        while(i<100){
            bufx = (bufx + processAcel(AXH, AXL)) / 2;
            bufy = (bufy + processAcel(AYH, AYL)) / 2;
            bufz = (bufz + processAcel(AZH, AZL)) / 2;
            i++;
        }


        /* Obtenemos nuestro offset */
        offset[0] = 0 - bufx;  //Offset X
        offset[1] = 0 - bufy;  //Offset Y
        offset[2] = 1.0 - bufz;  //Offset Z

        /* Pasamos de unidades de g a bits. 2048 porque hemos puesto resolucion de +/- 16g, por tanto 2^16/32, nos da que
         * 1g son 2048bits. Es un factor de conversion.
         */
        dos_byte[0] = offset[0] * 2048.0;
        dos_byte[1] = offset[1] * 2048.0;
        dos_byte[2] = offset[2] * 2048.0;

        /* Aveces va mejor haciendo un desplazamiento de un lugar a la izquierda, porque el offset esta en 15 bits([15:0] y [7:1]),
         *  y una valor de aceleraci�n son 16 bits
         */
        desplazo_bytes[0] = dos_byte[0];// << 1;  //BytesX
        desplazo_bytes[1] = dos_byte[1];// << 1;  //BytesY
        desplazo_bytes[2] = dos_byte[2] << 1;  //BytesZ

        /* Sumamos nuestro offset obtenido al predeterminado de fabrica que trae la IMU */
        OFF_TOTAL[0] = fabrica_off[0] + desplazo_bytes[0]; //OffTotalX
        OFF_TOTAL[1] = fabrica_off[1] + desplazo_bytes[1]; //OffTotalY
        OFF_TOTAL[2] = fabrica_off[2] + desplazo_bytes[2]; //OffTotalZ

        /* Separamos los offsets de datos de 16bits(juntos) a 2 bits de 8 (separados), para poderlos meter en los registros */
        off_final[0] = OFF_TOTAL[0] >> 8 & 0xff; //X_OFFSET_H_FINAL
        off_final[1] = OFF_TOTAL[0] & 0xff; //X_OFFSET_L_FINAL
        off_final[2] = OFF_TOTAL[1] >> 8 & 0xff; //Y_OFFSET_H_FINAL
        off_final[3] = OFF_TOTAL[1] & 0xff; //Y_OFFSET_L_FINAL
        off_final[4] = OFF_TOTAL[2] >> 8 & 0xff; //Z_OFFSET_H_FINAL
        off_final[5] = OFF_TOTAL[2] & 0xff; //Z_OFFSET_L_FINAL

        /* Escribimos los nuevos offset en los registros de la IMU */
        I2C_WriteIMU(0x77, off_final[0]);
        I2C_WriteIMU(0x78, off_final[1]);
        I2C_WriteIMU(0x7A, off_final[2]);
        I2C_WriteIMU(0x7B, off_final[3]);
        I2C_WriteIMU(0x7D, off_final[4]);
        I2C_WriteIMU(0x7E, off_final[5]);


        x = processAcel(AXH, AXL);
        y = processAcel(AYH, AYL);
        z = processAcel(AZH, AZL);
    }
}

float error;
float angulo_actual;
float integral;
float error_anterior = 0;
float dif_t;
float proporcional;
float derivativo;
Types_FreqHz freq;

float calcul_PID(float tiempo_incial){

    float kp = 0.65;//0.6;
    float ki = 0;//.065;//0.07;//0.0993;
    float kd = 0.10051;//+a*0.001;//0.095; //0.092875;


    angulo_actual = pitch();
    int j = 0;
    while(j<16){
        angulo_actual =  angulo_actual + pitch();
        //delay(200);
        j++;
    }
    angulo_actual = angulo_actual / 16;
    error = angulo_giro - angulo_actual;

    tiempo_final = Timestamp_get32();
    Timestamp_getFreq(&freq);

    dif_t = (tiempo_final - tiempo_inicial)/(freq.lo);
    proporcional = kp * error;
    derivativo = kd * (error - error_anterior) / dif_t;
    integral = integral + ki * error * dif_t;

    float resultado_pid = proporcional + integral + derivativo;

    error_anterior = error;

    tiempo_inicial = tiempo_final;

    return resultado_pid;

}
