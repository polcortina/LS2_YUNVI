/* Board Header file */

#include "HEADER.h"

void init_motors(void){

    dutyValue_0 = 850;
    dutyValue_1 = 850;

    PWM_Params_init(&params_0);
    params_0.idleLevel = PWM_IDLE_LOW;
    params_0.periodUnits = PWM_PERIOD_US;   // Period is in us
    params_0.periodValue = 10000;             //20ms
    params_0.dutyUnits = PWM_DUTY_US;       // Duty is in us
    params_0.dutyValue = 0;                 // 0us duty cycle
    pwm0 = PWM_open(Board_PWM0, &params_0);
    if (pwm0 == NULL) {
        System_printf("PWM0 did not open");
        System_flush();
    }

    PWM_Params_init(&params_1);
    params_1.periodUnits = PWM_PERIOD_US;   // Period is in us
    params_1.periodValue = 10000;             // 20ms
    params_1.dutyUnits = PWM_DUTY_US;       // Duty is in us
    params_1.dutyValue = 0;                 // 0us duty cycle
    pwm1 = PWM_open(Board_PWM1, &params_1);
    if (pwm1 == NULL) {
        System_printf("PWM1 did not open");
        System_flush();
    }

    PWM_setDuty(pwm0, dutyValue_0);
    PWM_setDuty(pwm1, dutyValue_1);

    PWM_start(pwm0);
    PWM_start(pwm1);

    delay_s(4);
}


int error_motor = 11;
int encendre = 0;
int   duty_esquerra, duty_dreta;

void rampa_motors(void){

    int ramp;
    for (ramp=1060; ramp<1100; ramp += 5){  //1100
        PWM_setDuty(pwm0, ramp + 10);
        PWM_setDuty(pwm1, ramp);
    }
}

void moure_motors(void){
    if (encendre == 0){
        duty_esquerra = 1160 - res_pid ;
        duty_dreta = 1160 + res_pid;

        duty_esquerra = dutymax(duty_esquerra)+ error_motor;
        duty_dreta = dutymax(duty_dreta);

        PWM_setDuty(pwm0, duty_esquerra);
        PWM_setDuty(pwm1, duty_dreta);
    }else{
        PWM_setDuty(pwm0, 850);
        PWM_setDuty(pwm1, 850);
    }
}


void lectura_mando(uint8_t state){
    switch(state){
    case 0:
        if(encendre == 1){
            rampa_motors();
            encendre = 0;
        }
        angulo_giro = 0;
        break;
    case 1:
        angulo_giro = -5;
            break;
    case 2:
        angulo_giro = -20;
            break;
    case 3:
        angulo_giro = -15;
            break;
    case 4:
        angulo_giro = -10;
            break;
    case 5:
        angulo_giro = 10;
            break;
    case 6:
        angulo_giro = 15;
            break;
    case 7:
        angulo_giro = 20;
            break;
    case 8:
        angulo_giro = 5;
            break;
    case 9:
        encendre = 1;
        angulo_giro = 0;
            break;
    }
}
// maxim 70
int dutymax(int dutyValue){
    if (dutyValue > 1190){
        return 1190;
    }
    else if (dutyValue < 1060){
        return 1060;
    }else
        return dutyValue;
}


void delay_s(uint8_t seg){
    TIMER32_1 -> LOAD = seg*50000000;
    TIMER32_1->CONTROL = 0xC2;
    while((TIMER32_1->RIS & 1) == 0);
    TIMER32_1->INTCLR = 0;
}


