
/*
 *  ======== empty_min.c ========
 */
#include "HEADER.h"

extern Task_Handle task1;

UART_Handle uart;
UART_Params uartParams;


void drone(UArg arg0, UArg arg1);
void init_UART(void);

/*
 *  ======== main ========
 */
int main(void)
{
    /* Call init functions */
    Board_init();
    GPIO_init();
    PWM_init();
    UART_init();


    init_motors();
    init_UART();


    /* Start BIOS */
    BIOS_start();

    return (0);
}

int errorm = 10;
float angulo_actual;

int duty_esquerra, duty_dreta;

signed char angulo;

int m = 30;
//float tiempo_inicial =0, tiempo_final;

float dif_t;
Types_FreqHz freq;

void drone(UArg arg0, UArg arg1)            //Task1
{
    Offset_IMU();
    delay_s(1);
    rampa_motors();
    while(1){
        angulo_actual = pitch();
        int j = 0;
        while(j<16){
            angulo_actual =  angulo_actual + pitch();
            j++;
        }
        angulo = angulo_actual / 16;

        if(angulo > 0){
            duty_esquerra = 1200 + m;
            duty_dreta = 1200 - m;
        }
        if(angulo < 0){
            duty_esquerra = 1200- m;
            duty_dreta = 1200 + m;
        }

        tiempo_final = Timestamp_get32();
        Timestamp_getFreq(&freq);

        dif_t = (tiempo_final - tiempo_inicial)/(freq.lo);
        PWM_setDuty(pwm0, duty_esquerra + errorm);
        PWM_setDuty(pwm1, duty_dreta);
        UART_write(uart, &angulo, 1);
        tiempo_inicial = tiempo_final;


    }
}


void init_UART(void){

    // Create a UART with data processing off.
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.baudRate = 115200;
    uartParams.writeTimeout = 10;
    // Open an instance of the UART drivers
    uart = UART_open(Board_UART0, &uartParams);

    if (uart == NULL) {
        // UART_open() failed
        while (1);
    }

}


