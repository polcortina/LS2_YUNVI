#ifndef PWM_MOTORS_H_
#define PWM_MOTORS_H_

#include "HEADER.h"

PWM_Handle pwm0;
PWM_Params params_0;
PWM_Handle pwm1;
PWM_Params params_1;
uint32_t   dutyValue_0, dutyValue_1;
signed char angulo_giro;

void init_motors(void);
void rampa_motors(void);
int dutymax(int dutyValue);
void moure_motors(void);
void lectura_mando(uint8_t state);
void delay_s(uint8_t seg);


#endif /* PWM_MOTORS_H_ */
