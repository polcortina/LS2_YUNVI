/*
 * Headers.h
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#ifndef HEADERS_H_
#define HEADERS_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Log.h>
//#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/hal/Hwi.h>
#include <ti/sysbios/knl/Swi.h>
#include <ti/sysbios/knl/Task.h>
//#include <ti/sysbios/hal/Timer.h>
#include <ti/sysbios/knl/Semaphore.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/ADC.h>
#include <ti/drivers/SPI.h>

/* driverlib headers */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h> /*necessary for timer*/
#include <ti/grlib/grlib.h>
#include "LcdDriver/Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include <ti/devices/msp432p4xx/inc/msp.h>

/* Board Header file */
#include "Board.h"
#include "nRF24_MSP432.h"
#include "ADC_joystick.h"
#include "LCD.h"


#endif /* HEADERS_H_ */
