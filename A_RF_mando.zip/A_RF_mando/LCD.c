/*
 * LCD.c
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#include "Headers.h"

int cont_2 = 0;
int cont_3 = 0;

void borde_bateria(void){           //FUNCION PARA PRINTEAR EL BORDE DE LA BATERIA.
    R1.xMin = 45;
    R1.xMax = 80;
    R1.yMin = 69;
    R1.yMax = 116;
    R6.xMin = 58;
    R6.xMax = 68;
    R6.yMin = 65;
    R6.yMax = 69;
    Graphics_drawRectangle(&g_sContext,&R1); // OBLIGATORIO PARA HACER EL BORDE BATERIA
    Graphics_fillRectangle(&g_sContext,&R6); // OBLIGATORIO PARA HACER EL PUNTITO DE ARRIBA DE LA PILA

}

void primera_barra(void){           // EN ESTA FUNCION SE PASAN VALORES A LA ESTRUCTURA
    R2.xMin = 48;                   // PARA PRINTEAR LA PRIMERA BARRA DE LA BATERIA
    R2.xMax = 77;
    R2.yMin = 105;
    R2.yMax = 113;
    Graphics_fillRectangle(&g_sContext,&R2);

}

void segunda_barra(void){           // EN ESTA FUNCION SE PASAN VALORES A LA ESTRUCTURA
    R3.xMin = 48;                   // PARA PRINTEAR LA SEGUNDA BARRA DE LA BATERIA
    R3.xMax = 77;
    R3.yMin = 94;
    R3.yMax = 102;
    Graphics_fillRectangle(&g_sContext,&R3);

}

void tercera_barra(void){          // EN ESTA FUNCION SE PASAN VALORES A LA ESTRUCTURA
    R4.xMin = 48;                  // PARA PRINTEAR LA TERCERA BARRA DE LA BATERIA
    R4.xMax = 77;
    R4.yMin = 83;
    R4.yMax = 91;
    Graphics_fillRectangle(&g_sContext,&R4);

}

void cuarta_barra(void){           // EN ESTA FUNCION SE PASAN VALORES A LA ESTRUCTURA
    R5.xMin = 48;                  // PARA PRINTEAR LA CUARTA BARRA DE LA BATERIA
    R5.xMax = 77;
    R5.yMin = 72;
    R5.yMax = 80;
    Graphics_fillRectangle(&g_sContext,&R5);

}

void comparacion_bateria(void){    // EN ESTA FUNCION SE CREA UNA ESTRUCTURA PARA PRINTEAR LA
    borde_bateria();               // BATERIA EN FUNCION DE LA BATERIA DEL DRONE.

    if(valor_bateria<=110){
            if(cont_3==0){
                Graphics_clearDisplay(&g_sContext);
                cont_3++;
            }

            else{

                cont_2 = 0;

            }
        }

    else if((110<valor_bateria) && (valor_bateria<=130)){
        if(cont_2==0){
            Graphics_clearDisplay(&g_sContext);
            cont_2++;
        }

        else{

            primera_barra();
            cont_3 = 0;

        }
    }

    else if((130<valor_bateria) && (valor_bateria<=140)){

        if(cont_3==0){
            Graphics_clearDisplay(&g_sContext);
            cont_3++;
        }

        else{
            primera_barra();
            segunda_barra();
            cont_2 = 0;
        }
    }
    else if((140<valor_bateria) && (valor_bateria<=150)){
        if(cont_2==0){
            Graphics_clearDisplay(&g_sContext);
            cont_2++;
        }
        else{
            primera_barra();
            segunda_barra();
            tercera_barra();
            cont_3=0;
        }
    }
    else{
        if(cont_3==0){
            Graphics_clearDisplay(&g_sContext);
            cont_3++;
        }
        else{
            primera_barra();
            segunda_barra();
            tercera_barra();
            cuarta_barra();
            cont_2=0;
        }

    }
}



