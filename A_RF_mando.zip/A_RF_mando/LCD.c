/*
 * LCD.c
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#include "Headers.h"


void borde_bateria(void){
    R1.xMin = 45;
    R1.xMax = 80;
    R1.yMin = 69;
    R1.yMax = 116;
    R6.xMin = 58;
    R6.xMax = 68;
    R6.yMin = 65;
    R6.yMax = 69;
    Graphics_drawRectangle(&g_sContext,&R1); // OBLIGATORIO PARA HACER EL BORDE BATERIA
    Graphics_fillRectangle(&g_sContext,&R6); // OBLIGATORIO PARA HACER EL PUNTITO DE ARRIBA DE LA PILA

}

void primera_barra(void){
    R2.xMin = 48;
    R2.xMax = 77;
    R2.yMin = 105;
    R2.yMax = 113;
    Graphics_fillRectangle(&g_sContext,&R2);

}

void segunda_barra(void){
    R3.xMin = 48;
    R3.xMax = 77;
    R3.yMin = 94;
    R3.yMax = 102;
    Graphics_fillRectangle(&g_sContext,&R3);

}

void tercera_barra(void){
    R4.xMin = 48;
    R4.xMax = 77;
    R4.yMin = 83;
    R4.yMax = 91;
    Graphics_fillRectangle(&g_sContext,&R4); // OBLIGATORIO PARA HACER EL PUNTITO DE ARRIBA DE LA PILA

}

void cuarta_barra(void){
    R5.xMin = 48;
    R5.xMax = 77;
    R5.yMin = 72;
    R5.yMax = 80;
    Graphics_fillRectangle(&g_sContext,&R5); // OBLIGATORIO PARA HACER EL PUNTITO DE ARRIBA DE LA PILA

}

void comparacion_bateria(void){
    borde_bateria();
    if(valor_bateria<=130){
        //Graphics_clearDisplay(&g_sContext);
        primera_barra();
    }
    else if((130<valor_bateria) && (valor_bateria<=140)){
        //Graphics_clearDisplay(&g_sContext);
        primera_barra();
        segunda_barra();
    }
    else if((140<valor_bateria) && (valor_bateria<=150)){
        //Graphics_clearDisplay(&g_sContext);
        primera_barra();
        segunda_barra();
        tercera_barra();
    }
    else{
        //Graphics_clearDisplay(&g_sContext);
        primera_barra();
        segunda_barra();
        tercera_barra();
        cuarta_barra();
    }
}



