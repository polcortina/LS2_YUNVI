/* Board Header file */
#include "Headers.h"

// Handles swi, tareas y sem�foro
extern Swi_Handle swi0;
extern Swi_Handle swi1;
extern Swi_Handle swi2;
extern Task_Handle task0;
extern Task_Handle task1;
extern Semaphore_Handle mySem;

// Declaraci�n de prototipos
void HWI_BOTON_1(UArg arg);
void HWI_BOTON_2(UArg arg);
void HWI_BOTON_JOYSTICK(UArg arg);
void SWI_BOTON_1(UArg arg0, UArg arg1);
void SWI_BOTON_2(UArg arg0, UArg arg1);
void SWI_BOTON_JOYSTICK(UArg arg0, UArg arg1);
void TaskFxn_0(UArg arg0, UArg arg1);
void TaskFxn_1(UArg arg0, UArg arg1);

uint8_t lectura_registro;
uint8_t addr[5];
signed char PLD[1];
uint8_t reg_status;
uint8_t dato_recibido[1];
uint8_t contador = 0;
uint8_t control = 0;


int main(void)
{
    /* Call board init functions */
    Board_init();
    GPIO_init();
    ADC_init();

    /* Habilitamos interrupciones en los pulsadores */
    GPIO_enableInt(BOTON_MANDO);
    GPIO_enableInt(BOTON_MANDO_2);
    GPIO_enableInt(BOTON_MANDO_JOYSTICK);
    GPIO_clearInt(BOTON_MANDO);
    GPIO_clearInt(BOTON_MANDO_2);
    GPIO_clearInt(BOTON_MANDO_JOYSTICK);


    /* Inicializacion de la pantalla */
    Crystalfontz128x128_Init();
    /* Orientacion de la pantalla */
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_BLACK); //COLOR DE LAS LETRAS DEL LCD
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE); //COLOR PANTALLA LCD
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);

    // Direcci�n TX y RX del nRF24
    addr[0] = 0xE7;
    addr[1] = 0xE7;
    addr[2] = 0xE7;
    addr[3] = 0xE7;
    addr[4] = 0xE7;

    ADC_joystick=0;
    ADC_acelerometro=0;
    valor_bateria = 100;

    /* Turn on user LED  */
    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);

    inicializar_SPI();
    cnt = 0;
    i = 0;
    x = 0;

    /* Start BIOS */
    BIOS_start();

    return (0);
}


void HWI_BOTON_1(UArg arg)
{
    if (P5IFG & 0x02){                             // Interrupci�n debida al S1
        GPIO_clearInt(BOTON_MANDO);                // Limpiamos INT
        Swi_post(swi0);                            // Llamamos al SWI_BOTON_1
    }

}

void HWI_BOTON_2(UArg arg){

    if (P3IFG & 0x20){                             // Interrupci�n debida al S1
        GPIO_clearInt(BOTON_MANDO_2);              // Limpiamos INT
        Swi_post(swi1);                            // Llamamos al SWI_BOTON_2
    }
}

void HWI_BOTON_JOYSTICK(UArg arg)
{
    if (P4IFG & 0x02){                             // Interrupci�n debida al S1
        GPIO_clearInt(BOTON_MANDO_JOYSTICK);                // Limpiamos INT
        Swi_post(swi2);                            // Llamamos al SWI_BOTON_1
    }

}


void SWI_BOTON_1(UArg arg0, UArg arg1)
{
    GPIO_toggle(Board_GPIO_LED0);                  // Conmutamos LED0
    Semaphore_post(mySem);                         // Desbloqueamos la tarea de enviar valor angulo.
}

void SWI_BOTON_2(UArg arg0, UArg arg1)             //SWI utilizado para apagar el drone.
{
    contador = 1;
}

void SWI_BOTON_JOYSTICK(UArg arg0, UArg arg1)     //SWI que alterna el control del drone con el
{                                                 //joystick del mando o con el acelerometro.
    if (control == 0){
        control = 1;
    }
    else{
        control = 0;
    }
}


void TaskFxn_0(UArg arg0, UArg arg1)            //TASK para enviar el valor del angulo deseado
{                                               //se desbloquea cada vez que se pulse el boton.
    init_RF();

    while(1){

        Semaphore_pend(mySem,BIOS_WAIT_FOREVER); //Semaforo para bloquear la tasca.
        if(contador==1){                         //Condicion para apagar el drone.
            valor_angulo = 9;
        }
        contador = 0;
        PLD[0] = valor_angulo;
        CE_disable();
        w_reg(RF24_STATUS, 0x7E); // Limpiamos bits TX_DS y MAX_RT
        reg_status = r_reg(RF24_STATUS);
        while(!(reg_status & RF24_TX_DS)){
            reset_FIFO();
            TX_mode(addr, 1);
            w_PLD(1, PLD);
            pulse_CE();
            reg_status = r_reg(RF24_STATUS);
            w_reg(RF24_STATUS, 0x1E);
            reg_status = r_reg(RF24_STATUS);

        }
        w_reg(RF24_STATUS, 0x7E);
    }
}


void TaskFxn_1(UArg arg0, UArg arg1){

    init_ADC_joystick();            /*Llamamos la funcion que inicializara nuestro ADC.*/
    init_ADC_acelerometro();   /*Llamamos la funcion que inicializara nuestro ADC del acelerometro.*/


    while(1){

        reset_FIFO();
        RX_mode(addr, 4);
        reg_status = r_reg(RF24_STATUS);
        if(reg_status & RF24_RX_DR){
            Read_RX_PLD(4,dato_recibido);
            w_reg(RF24_STATUS, 0x7E);
        }

        R.xMin = 10;
        R.xMax = 120;
        R.yMin = 20;
        R.yMax = 10;
        Graphics_drawRectangle(&g_sContext,&R);
        ADC_joystick = lectura_ADC_joystick(); //Pasamos el valor de la lectura del joystick al
                                               //valor del ADC_joystick
        ADC_acelerometro = lectura_ADC_acelerometro();
                                               //Pasamos el valor de la lectura del joystick al
                                               //valor del ADC_acelerometro
        valor_bateria = dato_recibido[0];      //Guardamos el valor del dato recibido de la bateria
                                               //del drone.
        comparacion_bateria();                 //Comprobamos el estado de la bateria.


        switch(control){
        case(0):                            //Entramos en el modo joystick.
                control_joystick();
        break;
        case(1):                            //Entramos en el modo acelerometro.
                control_acelerometro();
        break;

        }

        Task_yield();
    }
}






