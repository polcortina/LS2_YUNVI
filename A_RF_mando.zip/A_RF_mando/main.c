/* Board Header file */
#include "Headers.h"

// Handles swi, tareas y sem�foro
extern Swi_Handle swi0;
extern Swi_Handle swi1;
extern Task_Handle task0;
extern Task_Handle task1;
extern Semaphore_Handle mySem;

// Declaraci�n de prototipos
void HWI_BOTON_1(UArg arg);
void HWI_BOTON_2(UArg arg);
void SWI_BOTON_1(UArg arg0, UArg arg1);
void SWI_BOTON_2(UArg arg0, UArg arg1);
void TaskFxn_0(UArg arg0, UArg arg1);
void TaskFxn_1(UArg arg0, UArg arg1);

uint8_t lectura_registro;
uint8_t addr[5];
signed char PLD[1];
uint8_t reg_status;
uint8_t dato_recibido[1];
uint8_t contador = 0;
int valor_angulo;


int main(void)
{
    /* Call board init functions */
    Board_init();
    GPIO_init();
    ADC_init();

    /* Habilitamos interrupciones en los pulsadores */
    GPIO_enableInt(BOTON_MANDO);
    GPIO_enableInt(BOTON_MANDO_2);
    GPIO_clearInt(BOTON_MANDO_2);

    /* Inicializacion de la pantalla */
    Crystalfontz128x128_Init();
    /* Orientacion de la pantalla */
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);
    Graphics_initContext(&g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);
    Graphics_setForegroundColor(&g_sContext, GRAPHICS_COLOR_BLACK); //COLOR DE LAS LETRAS DEL LCD
    Graphics_setBackgroundColor(&g_sContext, GRAPHICS_COLOR_WHITE); //COLOR PANTALLA LCD
    GrContextFontSet(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);

    // Direcci�n TX y RX del nRF24
    addr[0] = 0xE7;
    addr[1] = 0xE7;
    addr[2] = 0xE7;
    addr[3] = 0xE7;
    addr[4] = 0xE7;

    ADC_joystick=0;
    valor_bateria = 100;

    /* Turn on user LED  */
    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);

    inicializar_SPI();

    /* Start BIOS */
    BIOS_start();

    return (0);
}


void HWI_BOTON_1(UArg arg)
{
    if (P5IFG & 0x02){                             // Interrupci�n debida al S1
        GPIO_clearInt(BOTON_MANDO);                // Limpiamos INT
        Swi_post(swi0);                            // Llamamos al SWI_BOTON_1
    }

}

void HWI_BOTON_2(UArg arg){

    if (P3IFG & 0x20){                             // Interrupci�n debida al S1
        GPIO_clearInt(BOTON_MANDO_2);              // Limpiamos INT
        Swi_post(swi1);                            // Llamamos al SWI_BOTON_2
    }
}


void SWI_BOTON_1(UArg arg0, UArg arg1)
{
    GPIO_toggle(Board_GPIO_LED0);                  // Conmutamos LED0
    Semaphore_post(mySem);                         // Desbloqueamos
}

void SWI_BOTON_2(UArg arg0, UArg arg1)
{
    contador = 1;
}


void TaskFxn_0(UArg arg0, UArg arg1)
{
    init_RF();

    while(1){

        Semaphore_pend(mySem,BIOS_WAIT_FOREVER);
        if(contador==1){
            valor_angulo = 9;
        }
        contador = 0;
        PLD[0] = valor_angulo;
        CE_disable();
        w_reg(RF24_STATUS, 0x7E); // Limpiamos bits TX_DS y MAX_RT
        reg_status = r_reg(RF24_STATUS);
        while(!(reg_status & RF24_TX_DS)){
            reset_FIFO();
            TX_mode(addr, 1);
            w_PLD(1, PLD);
            pulse_CE();
            reg_status = r_reg(RF24_STATUS);
            w_reg(RF24_STATUS, 0x1E);
            reg_status = r_reg(RF24_STATUS);

        }
        w_reg(RF24_STATUS, 0x7E);
    }
}


void TaskFxn_1(UArg arg0, UArg arg1){

    init_ADC(); /*Llamamos la funcion que inicializara nuestro ADC.*/
    char string[10]; /*Creamos una String para poder printear por pantalla*/
    volatile int cnt = 0, i = 0, x=0;
    /*Definimos los contadores utilizados mas adelante*/

    while(1){

        reset_FIFO();
        RX_mode(addr, 4);
        reg_status = r_reg(RF24_STATUS);
        if(reg_status & RF24_RX_DR){
            Read_RX_PLD(4,dato_recibido);
            w_reg(RF24_STATUS, 0x7E);
        }

        R.xMin = 10;
        R.xMax = 120;
        R.yMin = 20;
        R.yMax = 10;
        Graphics_drawRectangle(&g_sContext,&R);
        ADC_joystick = lectura_ADC();
        valor_bateria = dato_recibido[0];
        sprintf(string, "X: %d \n", ADC_joystick);
        Graphics_drawStringCentered(&g_sContext,(int8_t *)string,8,64,50,OPAQUE_TEXT);

                /*En estas lineas le pasamos ciertos valores de xMin xMax yMin yMax para que la estructura
                  creada en la libreria de graficos recoja esos valores a los cuales la funcion drawRectangle
                  apuntara con un puntero de indireccion y dibujara un rectangulo de medida deseada.
                  Guardaremos el valor que recoja nuestro ADC en una variable que a continuacion printearemos
                  por el LCD con la funcion sprintf que junto con la funcion drawStringCentered haremos que
                  escriba dicha String en la posicion de la pantalla desada por el usuario.*/

        if((8000<ADC_joystick) && (ADC_joystick<=8150)){
            if(i==0){
                Graphics_clearDisplay(&g_sContext);
                i++;
            }
                /*Esta condicion esta establecida para que cuando el joystick se deje de pulsar y vuelva a la
                  posicion neutral la barra este completamente limpia (solo dibujado el rectangulo).
                  Hacemos este contador cnt para que solo limpie una vez la pantalla, si no cada vez que
                  movieramos el joystick la pantalla comenzaria a vibrar dando una experiencia incomoda.
                  */

                    else{
                        R.xMin = 10;
                        R.xMax = 120;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_drawRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        valor_angulo = 0;
                        x=0;
                        cnt=0;

            //Inicialmente el drone estara apagado, cuando se pulse el boton 1 los motores se encenderan.

                     }

           }

                /*Esta segunda condicion esta creada para que entre en bucle infinito hasta que se mueva el
                  joystick de nuevo, basicamente esta creada para que no "vibre" la pantalla. Reiniciamos los
                  contadores para las siguientes condiciones.*/

        else if(ADC_joystick<=1000){
                    if(x == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 10;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        x++;
                    }

                    else{

                        R.xMin = 10;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        cnt=0;
                        i=0;
                        valor_angulo = 2; // Valor real -20


                    }

                }

        else if((1000<ADC_joystick) && (ADC_joystick<=2500)){
                    if(cnt == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 20;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        cnt++;
                    }

                    else{
                        R.xMin = 20;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        x=0;
                        i=0;
                        valor_angulo = 3; // valor real -15

                    }
                }

        else if((2500<ADC_joystick) && (ADC_joystick<=5000)){
                    if(x == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 32;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        x++;
                    }

                    else{
                        R.xMin = 32;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        cnt=0;
                        i=0;
                        valor_angulo = 4; // valor real -10

                    }
                }

        else if((5000<ADC_joystick) && (ADC_joystick<=8000)){
                    if(cnt == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 48;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        cnt++;
                    }

                    else{
                        R.xMin = 48;
                        R.xMax = 64;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        x=0;
                        i=0;
                        valor_angulo = 1; // Valor real -5


                    }
                }

        else if((8150<ADC_joystick) && (ADC_joystick<=9500)){
                    if(x == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 64;
                        R.xMax = 80;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        x++;
                    }

                    else{
                        R.xMin = 64;
                        R.xMax = 80;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        cnt=0;
                        i=0;
                        valor_angulo = 8; //Valor real 5

                    }
                }

        else if((9500<=ADC_joystick) && (ADC_joystick<=12000)){
                    if(cnt == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 64;
                        R.xMax = 95;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        cnt++;
                    }

                    else{
                        R.xMin = 64;
                        R.xMax = 95;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        x=0;
                        i=0;
                        valor_angulo = 5; //Valor real 10

                    }
                }

        else if((12000<ADC_joystick) && (ADC_joystick<=14000)){
                    if(x == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 64;
                        R.xMax = 110;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        x++;
                    }

                    else{
                        R.xMin = 64;
                        R.xMax = 110;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        cnt=0;
                        i=0;
                        valor_angulo = 6; // Valor real 15

                    }
                }

        else {
                    if(cnt == 0){
                        Graphics_clearDisplay(&g_sContext);
                        R.xMin = 64;
                        R.xMax = 120;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        cnt++;
                    }

                    else{
                        R.xMin = 64;
                        R.xMax = 120;
                        R.yMin = 20;
                        R.yMax = 10;
                        Graphics_fillRectangle(&g_sContext,&R);
                        comparacion_bateria();
                        x=0;
                        i=0;
                        valor_angulo = 7; //Valor real 20

                    }
        }
        Task_yield();
    }
}




