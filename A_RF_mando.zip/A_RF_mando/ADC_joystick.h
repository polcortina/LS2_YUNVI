/*
 * ADC_joystick.h
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#ifndef ADC_JOYSTICK_H_
#define ADC_JOYSTICK_H_

#include "Headers.h"

// Handles ADC
ADC_Handle   adc;
ADC_Params   params;

// Variables
volatile uint16_t ADC_joystick;

// Funciones
void init_ADC();
uint16_t lectura_ADC();

#endif /* ADC_JOYSTICK_H_ */
