/*
 * ADC_joystick.h
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#ifndef ADC_JOYSTICK_H_
#define ADC_JOYSTICK_H_

#include "Headers.h"

// Handles ADC
ADC_Handle   adc;
ADC_Params   params;
ADC_Handle   adc1;
ADC_Params   params1;

// Variables
volatile uint16_t ADC_joystick;
volatile uint16_t ADC_acelerometro;
int valor_angulo;
volatile int cnt, i, x;
char string[10]; /*Creamos una String para poder printear por pantalla*/

// Funciones
void init_ADC_joystick();
uint16_t lectura_ADC_joystick();
void init_ADC_acelerometro();
uint16_t lectura_ADC_acelerometro();
void control_joystick();
void control_acelerometro();

#endif /* ADC_JOYSTICK_H_ */
