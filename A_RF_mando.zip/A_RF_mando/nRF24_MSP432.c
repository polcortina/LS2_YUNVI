
#include "Headers.h"

/************** FUNCI�N INICIALIZACI�N SPI ********************/

void inicializar_SPI(void){

    SPI_Params      spiParams;

    SPI_init();  // Initialize the SPI driver
    SPI_Params_init(&spiParams);  // Initialize SPI parameters

    spiParams.transferMode = SPI_MODE_BLOCKING;
    spiParams.transferTimeout = SPI_WAIT_FOREVER;
    spiParams.transferCallbackFxn = NULL;
    spiParams.mode = SPI_MASTER;
    spiParams.bitRate = 1000000;   //1MHz SPI clock
    spiParams.dataSize = 8;       // 8-bit data size
    spiParams.frameFormat= SPI_POL0_PHA0;

    spi = SPI_open(Board_SPI1, &spiParams);
    if (spi == NULL) {
            while (1);  // SPI_open() failed
            }
    else {
        System_printf("SPI inicializado\n");
    }
}


/************** FUNCI�N TRANSFERENCIA SPI ********************/

uint8_t master_SPI_transaction(uint8_t addr)
{
    uint8_t transmitBuffer[1] = {0};
    transmitBuffer[0] = addr;
    SPI_Transaction   spiTransaction;

    uint8_t receiveBuffer[MSGSIZE];

    // Fill in transmitBuffer
    spiTransaction.count = MSGSIZE;
    spiTransaction.txBuf = (void *)transmitBuffer;
    spiTransaction.rxBuf = (void *)receiveBuffer;

    SPI_transfer(spi, &spiTransaction);

    return receiveBuffer[0];
}


/************** FUNCI�N PARA ESCRIBIR EN REGISTROS DE 8 BITS DEL nRF24 ********************/

void w_reg(uint8_t addr, uint8_t dato)
{
    CSN_enable();                                     // CSN a 0
    master_SPI_transaction(nRF24_W_REGISTER | addr);  // Instrucci�n de escribir en el registro con direcci�n "addr"
    master_SPI_transaction(dato);                     // Enviamos el dato que queremos escribir
    CSN_disable();                                    // CSN a 1

}


/************** FUNCI�N PARA LEER REGISTROS DE 8 BITS DEL nRF24 ********************/

uint8_t r_reg(uint8_t addr){

    uint8_t registro;
    CSN_enable();                                         // CSN a 0
    master_SPI_transaction(nRF24_R_REGISTER | addr);      // Instrucci�n de leer el registro con direcci�n "addr"
    registro=master_SPI_transaction(nRF24_NOP);           // Utilizamos la instrucci�n "no operation"
                                                          // para que pasen 8 clclos m�s y tener
                                                          // el dato listo en el bufer de recepci�n
    CSN_disable();                                        // CSN a 1
    return registro;                                      // Devolvemos el contenido del registro que hemos le�do

}

/********************* FUNCI�N PARA ESCRIBIR LA DIRECCI�N DEL TX **************************/


void w_tx_addr(uint8_t *addr){

    int i;

    CSN_enable();                                                // CSN a 0
    master_SPI_transaction(nRF24_W_REGISTER | RF24_TX_ADDR);     // Instrucci�n de escribir en el registro que debe contener la direcci�n del TX
    for (i=4; i>=0; i--) {                                       // Recorremos todoo el buffer addr
        master_SPI_transaction(addr[i]);                         // Transferimos cada byte de direcci�n v�a MOSI
    }
    CSN_disable();                                               // CSN a 1
}


/********************* FUNCI�N PARA ESCRIBIR LA DIRECCI�N DEL RX **************************/

void w_rx_addr(uint8_t *addr){

    int i;
    CSN_enable();                                                // CSN a 0
    master_SPI_transaction(nRF24_W_REGISTER |  RF24_RX_ADDR_P0);     // Instrucci�n de escribir en el registro que debe contener la direcci�n del TX
    for (i=4; i>=0; i--) {                                       // Recorremos todoo el buffer addr
        master_SPI_transaction(addr[i]);                         // Transferimos cada byte de direcci�n v�a MOSI
    }
    CSN_disable();                                               // CSN a 1
}


/**************FUNCI�N PARA ESCRIBIR PLD DE N BYTES ********************/

void w_PLD(uint8_t TX_RX_Payload_Width, signed char *pld){

    int i;
    CSN_enable();                                      // CSN a 0
    master_SPI_transaction(nRF24_W_TX_PAYLOAD);        // Instrucci�n de escribir el payload
    for (i=0; i<TX_RX_Payload_Width; i++){             // Recorremos el pld
        master_SPI_transaction(pld[i]);                // y lo transferimos v�a MOSI
    }
    CSN_disable();                                     // CSN a 1
}

/************* PRUEBA PARA LEER PLD recibida ****************************/

void Read_RX_PLD(uint8_t PLD_width, uint8_t *RX_pld){

    uint8_t i;
    CSN_enable();
    master_SPI_transaction(nRF24_R_RX_PAYLOAD);
    for(i=0; i<PLD_width; i++){
           RX_pld[i] = master_SPI_transaction(nRF24_NOP);
    }
    CSN_disable();

}


/************** RESET FIFO ********************/

void reset_FIFO(void){

        CSN_enable();
        master_SPI_transaction(nRF24_FLUSH_TX);         //Borramos la memoria FIFO TX.
        master_SPI_transaction(nRF24_FLUSH_RX);         //Borramos la memoria FIFO RX.
        CSN_disable();

    }


/************ GENERACI�N DE UN PULSO DE CE ********************/

void pulse_CE()
{
    CE_enable();
    delay_ms(5);
    CE_disable();
}


/************ INICIALIZACI�N RF ********************/


void init_RF(){

    CE_disable();                           // CE a 0
    delay_ms(300);
    reset_FIFO();                           // Borramos el contenido de las  memorias TX FIFO y RX FIFO
    w_reg(RF24_EN_RXADDR, 0x00);            // Deshabilitamos RX pipes
    w_reg(RF24_EN_AA, 0x00);                // Deshabilitamos Auto ACK
    w_reg(RF24_RF_SETUP, 0x07);             // 1Mbps, 0dBm y LNA_Gain
    w_reg(RF24_RF_CH, 0x78);                // Canal 120 -> 2520 MHz
    w_reg(RF24_SETUP_AW, 0x03);             // 5 bytes de direcci�n
    w_reg(RF24_CONFIG, 0x00);               // Reset registro CONFIG

}


/************ MODO TX ********************/

void TX_mode(uint8_t *addr, uint8_t n_bytes_PLD){

    w_reg(RF24_EN_RXADDR, 0x01);           // Habilitamos RX pipes
    w_reg(RF24_EN_AA, 0x01);               // Habilitamos auto ACK pipe 0
    w_reg(RF24_RX_PW_P0, n_bytes_PLD);     // Definimos el n�mero de bytes del PLD
    w_reg(RF24_CONFIG, 0x7A);              // Interrupciones enmascaradas
                                           // Habilitamos CRC (1byte)
                                           // PWR_UP=1 y modo TX

    w_tx_addr(addr);                       // Definimos TX_addr
    w_rx_addr(addr);                       // Definimos RX_addr

}

/************ MODO RX ********************/

void RX_mode(uint8_t *addr, uint8_t n_bytes_PLD){

    w_reg(RF24_EN_RXADDR, 0x01);           // Habilitamos RX pipes
    w_reg(RF24_EN_AA, 0x01);               // Habilitamos auto ACK
    w_reg(RF24_RX_PW_P0, n_bytes_PLD);     // Definimos el n�mero de bytes del PLD
    w_reg(RF24_CONFIG, 0x7B);              // Interrupciones enmascaradas
                                           // Habilitamos CRC (1byte)
                                           // PWR_UP=1 y modo RX

    w_rx_addr(addr);                       // Definimos RX_addr
    delay_ms(2);
    CE_enable();                           // CE a 1 para pasar a modo RX
    delay_ms(2);

}


/******************** FUNCIONES PARA CSN Y CE **********************/

void CSN_enable(void)
{
    GPIO_write(CSN, 0);
}

void CSN_disable(void)
{
    GPIO_write(CSN, 1);
}

void CE_enable(void)
{
    GPIO_write(CE, 1);
}

void CE_disable(void)
{
    GPIO_write(CE, 0);
}


/******************** FUNCION DELAY **********************/

void delay_ms(uint16_t n)
{
    TIMER_A1->CTL = 0X02D1;
    TIMER_A1->EX0 = 7;
    TIMER_A1->CCR[0] = 50*n ;
    while((TIMER_A1->CCTL[0] & 1) == 0);
    TIMER_A1->CCTL[0] &= ~1;
}
