/*
 * LCD.h
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */

#ifndef LCD_H_
#define LCD_H_

#include "Headers.h"

//Estructuras LCD
Graphics_Rectangle R;           //ESTRUCTURA UTILIZADA PARA COORDENADAS DEL RECTANGULO
Graphics_Rectangle R1;
Graphics_Rectangle R2;
Graphics_Rectangle R3;
Graphics_Rectangle R4;
Graphics_Rectangle R5;
Graphics_Rectangle R6;

/* Graphic library context */
Graphics_Context g_sContext;

uint8_t valor_bateria;

//Funciones LCD

void borde_bateria();
void primera_barra();
void segunda_barra();
void tercera_barra();
void cuarta_barra();
void comparacion_bateria();

#endif /* LCD_H_ */
