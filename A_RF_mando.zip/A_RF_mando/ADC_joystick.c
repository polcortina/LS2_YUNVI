/*
 * ADC_joystick.c
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */
#include "Headers.h"


void init_ADC_acelerometro(){

    ADC_Params_init(&params1);
    adc1 = ADC_open(Board_ADC1, &params1);

    if (adc1 == NULL)
    {
        System_printf("ADC1 convert failed\n");
        System_flush();
        while (1); /*dejamos el sistema colgado*/
    }

}

void init_ADC_joystick(){

    ADC_Params_init(&params);
    adc = ADC_open(Board_ADC0, &params);

    if (adc == NULL)
    {
        System_printf("ADC0 convert failed\n");
        System_flush();
        while (1); /*dejamos el sistema colgado*/
    }

}



uint16_t lectura_ADC_joystick(){

    uint16_t adcValue0; /* ADC conversion result variables */
    int_fast16_t res;

    res = ADC_convert(adc, &adcValue0);
    if (res == ADC_STATUS_SUCCESS){
        ADC_joystick = adcValue0;

    }
    return  ADC_joystick;
}


uint16_t lectura_ADC_acelerometro(){

    uint16_t adcValue1; /* ADC conversion result variables */
    int_fast16_t res1;

    res1 = ADC_convert(adc1, &adcValue1);
    if (res1 == ADC_STATUS_SUCCESS){
        ADC_acelerometro = adcValue1;

    }
    return  ADC_acelerometro;
}


void control_joystick(void){ //Crearemos varias condiciones para los diversos rangos de angulos.

    sprintf(string, "MODO JOYSTICK");
    Graphics_drawStringCentered(&g_sContext,(int8_t *)string,16,64,50,OPAQUE_TEXT);


    if((8000<ADC_joystick) && (ADC_joystick<=8150)){
                if(i==0){
                    Graphics_clearDisplay(&g_sContext);
                    i++;
                }
                    /*Esta condicion esta establecida para que cuando el joystick se deje de pulsar y vuelva a la
                      posicion neutral la barra este completamente limpia (solo dibujado el rectangulo).
                      Hacemos este contador cnt para que solo limpie una vez la pantalla, si no cada vez que
                      movieramos el joystick la pantalla comenzaria a vibrar dando una experiencia incomoda.
                      */

                        else{
                            R.xMin = 10;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_drawRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            valor_angulo = 0;
                            x=0;
                            cnt=0;

       //Inicialmente el drone estara apagado, cuando se pulse el boton 1 los motores se encenderan.

                         }

               }

                    /*Esta segunda condicion esta creada para que entre en bucle infinito hasta que se mueva el
                      joystick de nuevo, basicamente esta creada para que no "vibre" la pantalla. Reiniciamos los
                      contadores para las siguientes condiciones.*/

            else if(ADC_joystick<=1000){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 10;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
    /*Creamos esta condicion para que entre una vez y por lo tanto solo borra una vez la pantalla*/
                        }

                        else{

                            R.xMin = 10;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 2; // Valor real -20


                        }

                    }

            else if((1000<ADC_joystick) && (ADC_joystick<=2500)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 20;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 20;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 3; // valor real -15

                        }
                    }

            else if((2500<ADC_joystick) && (ADC_joystick<=5000)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 32;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 32;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 4; // valor real -10

                        }
                    }

            else if((5000<ADC_joystick) && (ADC_joystick<=8000)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 48;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 48;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 1; // Valor real -5


                        }
                    }

            else if((8150<ADC_joystick) && (ADC_joystick<=9500)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 80;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 80;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 8; //Valor real 5

                        }
                    }

            else if((9500<=ADC_joystick) && (ADC_joystick<=12000)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 95;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 95;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 5; //Valor real 10

                        }
                    }

            else if((12000<ADC_joystick) && (ADC_joystick<=14000)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 110;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 110;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 6; // Valor real 15

                        }
                    }

            else {
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 7; //Valor real 20

                        }
            }


}

void control_acelerometro(void){
    sprintf(string, "MODO ACELEROMETRO");
    Graphics_drawStringCentered(&g_sContext,(int8_t *)string,20,64,50,OPAQUE_TEXT);

    if((8000<ADC_acelerometro) && (ADC_acelerometro<=8300)){
                if(i==0){
                    Graphics_clearDisplay(&g_sContext);
                    i++;
                }
                    /*Esta condicion esta establecida para que cuando el joystick se deje de pulsar y vuelva a la
                      posicion neutral la barra este completamente limpia (solo dibujado el rectangulo).
                      Hacemos este contador cnt para que solo limpie una vez la pantalla, si no cada vez que
                      movieramos el joystick la pantalla comenzaria a vibrar dando una experiencia incomoda.
                      */

                        else{
                            R.xMin = 10;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_drawRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            valor_angulo = 0;
                            x=0;
                            cnt=0;

                //Inicialmente el drone estara apagado, cuando se pulse el boton 1 los motores se encenderan.

                         }

               }

                    /*Esta segunda condicion esta creada para que entre en bucle infinito hasta que se mueva el
                      joystick de nuevo, basicamente esta creada para que no "vibre" la pantalla. Reiniciamos los
                      contadores para las siguientes condiciones.*/

            else if(ADC_acelerometro<=6000){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 10;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{

                            R.xMin = 10;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 2; // Valor real -20


                        }

                    }

            else if((6000<ADC_acelerometro) && (ADC_acelerometro<=6500)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 20;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 20;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 3; // valor real -15

                        }
                    }

            else if((6500<ADC_acelerometro) && (ADC_acelerometro<=7000)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 32;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 32;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 4; // valor real -10

                        }
                    }

            else if((7000<ADC_acelerometro) && (ADC_acelerometro<=8000)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 48;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 48;
                            R.xMax = 64;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 1; // Valor real -5


                        }
                    }

            else if((8300<ADC_acelerometro) && (ADC_acelerometro<=9000)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 80;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 80;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 8; //Valor real 5

                        }
                    }

            else if((9000<=ADC_acelerometro) && (ADC_acelerometro<=9500)){
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 95;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 95;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 5; //Valor real 10

                        }
                    }

            else if((9500<ADC_acelerometro) && (ADC_acelerometro<=10000)){
                        if(x == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 110;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            x++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 110;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            cnt=0;
                            i=0;
                            valor_angulo = 6; // Valor real 15

                        }
                    }

            else {
                        if(cnt == 0){
                            Graphics_clearDisplay(&g_sContext);
                            R.xMin = 64;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            cnt++;
                        }

                        else{
                            R.xMin = 64;
                            R.xMax = 120;
                            R.yMin = 20;
                            R.yMax = 10;
                            Graphics_fillRectangle(&g_sContext,&R);
                            //comparacion_bateria();
                            x=0;
                            i=0;
                            valor_angulo = 7; //Valor real 20

                        }
            }


}


