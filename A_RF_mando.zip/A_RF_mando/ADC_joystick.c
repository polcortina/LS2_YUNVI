/*
 * ADC_joystick.c
 *
 *  Created on: 21 ene. 2020
 *      Author: UX430
 */
#include "Headers.h"


void init_ADC(){

    ADC_Params_init(&params);
    adc = ADC_open(Board_ADC0, &params);

    if (adc == NULL)
    {
        System_printf("ADC0 convert failed\n");
        System_flush();
        while (1); /*dejamos el sistema colgado*/
    }

}



uint16_t lectura_ADC(){

    uint16_t adcValue0; /* ADC conversion result variables */
    int_fast16_t res;

    res = ADC_convert(adc, &adcValue0);
    if (res == ADC_STATUS_SUCCESS){
        ADC_joystick = adcValue0;

    }
    return  ADC_joystick;
}


